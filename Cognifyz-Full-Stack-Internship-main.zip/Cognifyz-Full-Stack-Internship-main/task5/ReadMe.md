# Task 5 -   Advanced API Usage and External API Integration
## Level 4 - Expert
## Objective of the task
⚡️Integrate an external API (e.g., third-party services) into your application. <br/>
⚡️Implement advanced API features such as rate limiting and error handling.

### [Live Preview](https://www.linkedin.com/posts/balaharisankar_cognifyz-cognifyztechnologies-cognifyzinternship-activity-7200214171781615619-uuuV?utm_source=share&utm_medium=member_desktop)
