# Tasks given by Cognifyz Technologies 
## Full-stack Development Internship
