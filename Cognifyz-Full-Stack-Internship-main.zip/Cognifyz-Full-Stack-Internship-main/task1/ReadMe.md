# Task 1 -  HTML Structure and Basic Server Interactions
## Level - Beginner
## Objective of the task
⚡️Setup a nodejs server using Express.js <br/>
⚡️Create Endpoint to handle form submission <br/>
⚡️Server Side Rendering using template engine (Ex: EJS)
### [Live Preview](https://www.linkedin.com/posts/balaharisankar_cognifyz-cognifyztechnologies-cognifyzinternship-activity-7192520331553562624-mOXP?utm_source=share&utm_medium=member_desktop)
