# Task 3 -   API Integration and Front-End Interaction
## Level - Advanced
## Objective of the task
⚡️Create RESTful API endpoints on the server for handling CRUD operations. <br/>
⚡️Develop a front-end interface that interacts with your own server API. <br/>
⚡️Fetch and display data from your API on the front end. 

### [Live Preview](https://www.linkedin.com/posts/balaharisankar_cognifyz-cognifyztechnologies-cognifyzinternship-activity-7197680471219056640-COL1?utm_source=share&utm_medium=member_desktop)
